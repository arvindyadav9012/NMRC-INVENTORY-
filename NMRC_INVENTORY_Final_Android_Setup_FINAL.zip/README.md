# NMRC INVENTORY Android

Android Studio / GitHub Actions project for NMRC INVENTORY.

## GitHub build
1. Upload the contents of this ZIP to the root of a GitHub repository.
2. Open Actions.
3. Select **Build NMRC INVENTORY APK**.
4. Select **Run workflow**.
5. Download the artifact **NMRC-INVENTORY-APK**.

The app label and launcher icon are explicitly defined as **NMRC INVENTORY**.
