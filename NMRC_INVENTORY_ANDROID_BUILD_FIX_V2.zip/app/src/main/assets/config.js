// NMRC INVENTORY V41.0 APK configuration.
// IMPORTANT: replace this with the FULL deployed NMRC INVENTORY Worker API URL ending in /api.
// Example: https://aurionpro-live-sync.<account>.workers.dev/api
window.AURION_API_BASE = ''; // Set your deployed Cloudflare Worker API URL ending in /api
window.AURION_API_KEY = '';
window.AURION_DRIVE_BACKUP_URL = '';
window.AURION_SYNC_POLL_MS = 1500;
