# NMRC INVENTORY - Android Build

This repository builds the **NMRC INVENTORY** debug APK using GitHub Actions.

## GitHub
1. Upload the contents of this folder to the repository root.
2. Open **Actions**.
3. Select **Build NMRC INVENTORY APK**.
4. Select **Run workflow**.
5. Download the `NMRC-INVENTORY-APK` artifact.

## Live API
Before using the APK for live data, set `window.AURION_API_BASE` in:
`app/src/main/assets/config.js`

It must be the full deployed Cloudflare Worker API URL ending in `/api`.

The Android build workflow does not depend on a local `gradlew` wrapper; GitHub Actions installs Gradle 8.9 directly.
