# NMRC INVENTORY — Android Studio / GitHub Actions package

This is an Android Studio source project that wraps the existing inventory portal web UI in a native Android WebView.

## GitHub
Upload the **contents of this ZIP** to a new GitHub repository (not the ZIP file itself), then open **Actions → Build NMRC INVENTORY APK → Run workflow**.

The workflow uses JDK 17, Android SDK, and Gradle 8.9. It uploads the generated debug APK as an Actions artifact.

## Important live API setting
Before building, edit `app/src/main/assets/config.js` and replace `https://YOUR-AURIONPRO-WORKER.workers.dev/api` with the exact deployed API URL for your live Cloudflare Worker. Do not change or drop your existing D1 tables.

## Current scope
- App label: NMRC INVENTORY
- Native Android WebView shell
- JavaScript + DOM storage enabled
- Internet permission
- GPS permissions for the portal's location feature
- Existing portal files included unchanged from the source package

This package is source code, not a precompiled APK.
